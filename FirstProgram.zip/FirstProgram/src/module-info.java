module firstProgram {
}